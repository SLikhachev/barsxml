
TYPES = dict(
    app=0,
    dsc=2,
    sto=5,
    pcr=7,
    ifa=8,
    tra=9
)


